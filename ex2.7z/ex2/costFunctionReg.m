function [J, grad] = costFunctionReg(theta, X, y, lambda)
%COSTFUNCTIONREG Compute cost and gradient for logistic regression with regularization
%   J = COSTFUNCTIONREG(theta, X, y, lambda) computes the cost of using
%   theta as the parameter for regularized logistic regression and the
%   gradient of the cost w.r.t. to the parameters. 

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;
grad = zeros(size(theta));

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost of a particular choice of theta.
%               You should set J to the cost.
%               Compute the partial derivatives and set grad to the partial
%               derivatives of the cost w.r.t. each parameter in theta

% in case of logistic regression hypothesis is sigmoid function of X*theta variable
h = sigmoid(X * theta);

% we do not set penalty on theta_0, which is at index 1 in octave
theta_f1 = theta;
theta_f1(1) = 0;

% since theta_0 is 0, this term won't change the sum result
% calculate element-wise squares of theta and store its sum
theta_f1_sum = sum(theta_f1.^2); 

% use formula of cost function for logistic regression with regularization term
J = -(1/m) * (y'*log(h) + (1 - y)'*log(1 - h)) + (lambda / (2*m))*theta_f1_sum;

% use formula of gradient
grad = ((1/m) * ((h-y)'*X)) .+ (lambda / m)*theta_f1';

% =============================================================

end
