function [J, grad] = cofiCostFunc(params, Y, R, num_users, num_movies, ...
                                  num_features, lambda)
%COFICOSTFUNC Collaborative filtering cost function
%   [J, grad] = COFICOSTFUNC(params, Y, R, num_users, num_movies, ...
%   num_features, lambda) returns the cost and gradient for the
%   collaborative filtering problem.
%

% Unfold the U and W matrices from params
X = reshape(params(1:num_movies*num_features), num_movies, num_features);
Theta = reshape(params(num_movies*num_features+1:end), ...
                num_users, num_features);

            
% You need to return the following values correctly
J = 0;
X_grad = zeros(size(X));
Theta_grad = zeros(size(Theta));

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost function and gradient for collaborative
%               filtering. Concretely, you should first implement the cost
%               function (without regularization) and make sure it is
%               matches our costs. After that, you should implement the 
%               gradient and use the checkCostFunction routine to check
%               that the gradient is correct. Finally, you should implement
%               regularization.
%
% Notes: X - num_movies  x num_features matrix of movie features
%        Theta - num_users  x num_features matrix of user features
%        Y - num_movies x num_users matrix of user ratings of movies
%        R - num_movies x num_users matrix, where R(i, j) = 1 if the 
%            i-th movie was rated by the j-th user
%
% You should set the following variables correctly:
%
%        X_grad - num_movies x num_features matrix, containing the 
%                 partial derivatives w.r.t. to each element of X
%        Theta_grad - num_users x num_features matrix, containing the 
%                     partial derivatives w.r.t. to each element of Theta
%

% 1. Cost function with no regulation

d = 1/2;

% A = X * Theta' : (num_movies x num_features) * (num_features x num_users) = (num_movies x num_users) = hypothesis
% B = A - Y      : (num_movies x num_users) = matrix of errors between hypothesis and ground truth
% C = B .* R     : (num_movies x num_users) = leave only those elements C(i,j), for which the corresponding R(i,j) == 1
%                   other elements become 0 and those values squared are also zero.
% Sum all elements and multiply by divisor

J = d * sum(sum(((X * Theta' - Y).*R).^2));

% 2. Gradients for X and Theta
% X_grad should have the same size as X, each row is a dJ/dx(i) = sum over j(r(i,j)=1) of (x(i)Theta(j) - y(i,j))*Theta(j)
% Theta_grad should have the same size as Theta, each row is a dJ/dTheta(i) = sum over i(r(i,j)=1) of (x(i)Theta(j) - y(i,j))*x(i)

X_grad = ((X * Theta' - Y).*R) * Theta;
Theta_grad = ((X * Theta' - Y).*R)' * X;

% 3. Regularization terms for cost function and its gradients
% For users  (Ru) we should find squares of all Theta elements, sum them and multiply the result by regularization parameter.
% For movies (Rm) we should find squares of all X elements, sum them and multiply the result by regularization parameter.
% Then add separate regularization factors to cost function.
% As for gradients, they have a bit different notation.
% In this case we need add lambda*X for dJ/dx and lambda*Theta for dJ/dTheta.

Ru = (lambda / 2) * sum(sum(Theta.^2));
Rm = (lambda / 2) * sum(sum(X.^2));

J = J + Ru + Rm;

X_grad = X_grad + lambda*X;
Theta_grad = Theta_grad + lambda*Theta;

% =============================================================

grad = [X_grad(:); Theta_grad(:)];

end
