function [mu sigma2] = estimateGaussian(X)
%ESTIMATEGAUSSIAN This function estimates the parameters of a 
%Gaussian distribution using the data in X
%   [mu sigma2] = estimateGaussian(X), 
%   The input X is the dataset with each n-dimensional data point in one row
%   The output is an n-dimensional vector mu, the mean of the data set
%   and the variances sigma^2, an n x 1 vector
% 

% Useful variables
[m, n] = size(X);

% You should return these values correctly
mu = zeros(n, 1);
sigma2 = zeros(n, 1);

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the mean of the data and the variances
%               In particular, mu(i) should contain the mean of
%               the data for the i-th feature and sigma2(i)
%               should contain variance of the i-th feature.
%

% divisor, that depends on count of training examples
d = 1/m;

% we have matrix X of training examples, each row is separate one
% we should calculate vectors of mu and sigma_squared - parameters of Gaussian distribution
% each component of this vectors depend on corresponding columns in X and X-mu matrices as well as divisor scalar
% to calculate them, we should do this:

for i = 1:n
	mu(i) = d * sum(X(:,i));
	sigma2(i) = d * sum((X(:,i) - mu(i)).^2);
end

% =============================================================


end
