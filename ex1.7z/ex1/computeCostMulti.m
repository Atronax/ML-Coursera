function J = computeCostMulti(X, y, theta)
%COMPUTECOSTMULTI Compute cost for linear regression with multiple variables
%   J = COMPUTECOSTMULTI(X, y, theta) computes the cost of using theta as the
%   parameter for linear regression to fit the data points in X and y

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;

% theta vector should have (features + 1) values to correspond equation 
% y(k) = theta0*1 + theta(1)*feature(1,k) + ... + theta(n)*feature(n,k)
% make sure we have additional column of ones left of feature to find theta0
% X = [ones(m,1) X];

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost of a particular choice of theta
%               You should set J to the cost.

% the same vectorized version as for single feature
hypothesis = X * theta;

error = hypothesis - y;
error_squared = error.^2;
error_squared_sum = sum(error_squared);

J = (1 / (2*m)) * error_squared_sum;

% =========================================================================

end
