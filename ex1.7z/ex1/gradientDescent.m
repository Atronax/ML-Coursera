function [theta, J_history] = gradientDescent(X, y, theta, alpha, num_iters)
%GRADIENTDESCENT Performs gradient descent to learn theta
%   theta = GRADIENTDESCENT(X, y, theta, alpha, num_iters) updates theta by 
%   taking num_iters gradient steps with learning rate alpha

% Initialize some useful values
m = length(y); % number of training examples
J_history = zeros(num_iters, 1);

% in case of single feature in X matrix we have these:
% hypothesis equation is: h = theta0 + theta1*x,
% theta = vector (theta0, theta1), whera theta 0 - intercept term,
% make sure there is a column of ones left-side of the X data or add it here.
% X = [ones(m,1) X];

for iter = 1:num_iters

    % ====================== YOUR CODE HERE ======================
    % Instructions: Perform a single gradient step on the parameter vector
    %               theta. 
    %
    % Hint: While debugging, it can be useful to print out the values
    %       of the cost function (computeCost) and gradient here.
    %       
    
    % simultaneous update of all theta_j until the cost function will be minimized.
    
    J = (1/m) * ((X*theta - y)' * X)';

    theta = theta - alpha * J;
    

    % ============================================================

    % Save the cost J in every iteration    
    J_history(iter) = computeCost(X,y,theta);

    % : for debugging purposes :
    % if (iter > 1)
    %    if (J_history(iter) < J_history(iter - 1))
    %       fprintf("J value is less on this iteration then on previous\n");
    %    else
    %       fprintf("J value is higher on this iteration then on previous\n");
    %    end; 
    % end;
   

end

end
